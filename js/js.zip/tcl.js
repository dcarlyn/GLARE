require({
	baseUrl: '',
	packages: [
		{name: 'tcl', location: 'amd'}
	]
},['tcl/interp']);
